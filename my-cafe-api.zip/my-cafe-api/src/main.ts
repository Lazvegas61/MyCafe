import 'dotenv/config'; // ENV dosyasını yükler

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { UsersService } from './users/users.service';

async function bootstrap() {
  console.log("ENV TEST → DB_PASS =", process.env.DB_PASS);

  const app = await NestFactory.create(AppModule);

  // İlk kullanıcıları oluştur (superadmin + admin)
  const usersService = app.get(UsersService);
  await usersService.seedInitialUsers();

  await app.listen(3000);
  console.log('MyCafe API çalışıyor → http://localhost:3000');
}

bootstrap();
