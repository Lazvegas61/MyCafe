import GenelOzet from "./GenelOzet/GenelOzet";

export default function RaporlarIndex() {
  return <GenelOzet />;
}
