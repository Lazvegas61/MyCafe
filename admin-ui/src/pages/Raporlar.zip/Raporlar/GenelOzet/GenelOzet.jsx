import RaporFiltreBar from "@/components/Raporlar/RaporFiltreBar";

export default function GenelOzet({ ozet = {}, onFiltreChange }) {
  // 🔒 GUARD
  const {
    toplamCiro = 0,
    toplamAdet = 0,
    enCokKategori = "-",
    enCokUrun = "-",
    bilardoCiro = 0,
    bilardoOyun = 0,
  } = ozet;

  return (
    <div style={{ padding: 24, background: "#f5ead6" }}>
      <h2 style={{ marginBottom: 12, color: "#7a3e06" }}>Genel Özet</h2>

      <RaporFiltreBar onChange={onFiltreChange} />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 16,
          marginTop: 16,
        }}
      >
        <Kart baslik="Toplam Ciro" deger={`${toplamCiro.toLocaleString("tr-TR")} ₺`} />
        <Kart baslik="Toplam Adet" deger={toplamAdet} />
        <Kart baslik="En Çok Kategori" deger={enCokKategori} />
        <Kart baslik="En Çok Ürün" deger={enCokUrun} />
        <Kart baslik="Bilardo Cirosu" deger={`${bilardoCiro.toLocaleString("tr-TR")} ₺`} />
        <Kart baslik="Bilardo Oyun" deger={bilardoOyun} />
      </div>
    </div>
  );
}

function Kart({ baslik, deger }) {
  return (
    <div
      style={{
        background: "#fff",
        borderRadius: 12,
        padding: 16,
        boxShadow: "0 4px 12px rgba(0,0,0,.08)",
      }}
    >
      <div style={{ fontSize: 13, color: "#92400e", marginBottom: 6 }}>
        {baslik}
      </div>
      <div style={{ fontSize: 22, fontWeight: 700 }}>{deger}</div>
    </div>
  );
}
