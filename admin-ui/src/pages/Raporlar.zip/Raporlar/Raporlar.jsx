﻿import { useEffect, useState } from "react";
import raporMotoru from "@/services/raporMotoruV2";

import GenelOzet from "./GenelOzet/GenelOzet";
import KasaRaporu from "./KasaRaporu/KasaRaporu";
import GiderRaporu from "./GiderRaporlari/GiderRaporu";
import UrunRaporu from "./UrunRaporu/UrunRaporu";
import MasaRaporu from "./MasaRaporu/MasaRaporu";
import KategoriRaporu from "./KategoriRaporu/KategoriRaporu";
import BilardoRaporu from "./BilardoRaporu/BilardoRaporu";
if (typeof window !== "undefined") {
  window.__RAPOR_TEST__ = raporMotoru;
}



export default function Raporlar() {
  const [filtre, setFiltre] = useState({});
  const [ozet, setOzet] = useState(null);
  const [kasa, setKasa] = useState(null);
  const [giderler, setGiderler] = useState(null);
  const [urunler, setUrunler] = useState(null);
  const [masalar, setMasalar] = useState(null);
  const [kategoriler, setKategoriler] = useState(null);
  const [bilardo, setBilardo] = useState(null);




  useEffect(() => {
    // GENEL ÖZET
    const kategori = raporMotoru.kategoriRaporu(filtre);
    const urun = raporMotoru.urunRaporu(filtre);
    const bilardo = raporMotoru.bilardoRaporu(filtre);
    // BİLARDO
const bilardoRaporu = raporMotoru.bilardoRaporu(filtre);

setBilardo({
  toplamOyun: bilardoRaporu.toplamOyun || 0,
  toplamCiro: bilardoRaporu.toplamCiro || 0,
  ortalamaCiro:
    bilardoRaporu.toplamOyun > 0
      ? bilardoRaporu.toplamCiro / bilardoRaporu.toplamOyun
      : 0,
  detay: bilardoRaporu.detay || [],
});


    // MASA
const masaRaporu = raporMotoru.masaRaporu(filtre);
setMasalar(masaRaporu || []);

// KATEGORİ
const kategoriRaporu = raporMotoru.kategoriRaporu(filtre);
setKategoriler(kategoriRaporu || []);



    // ÜRÜN
const urunRaporu = raporMotoru.urunRaporu(filtre);
setUrunler(urunRaporu || []);


    setOzet({
      toplamCiro: kategori.reduce((t, k) => t + k.ciro, 0),
      toplamAdet: urun.reduce((t, u) => t + u.adet, 0),
      enCokKategori: kategori.sort((a, b) => b.ciro - a.ciro)[0]?.kategori || "-",
      enCokUrun: urun.sort((a, b) => b.ciro - a.ciro)[0]?.urunAd || "-",
      bilardoCiro: bilardo.toplamCiro || 0,
      bilardoOyun: bilardo.toplamOyun || 0,
    });

    // KASA
    const kasaRaporu = raporMotoru.kasaRaporu(filtre);
    setKasa({
      toplamKasa: kasaRaporu.toplam,
      nakit: kasaRaporu.nakit,
      kart: kasaRaporu.kart,
      havale: kasaRaporu.havale,
      hesabaYaz: kasaRaporu.hesabaYaz,
    });

    // GİDER
    const giderRaporu = raporMotoru.giderRaporu(filtre);
    setGiderler(giderRaporu || []);
  }, [filtre]);


  return (
    <div style={{ background: "#f5ead6", minHeight: "100vh" }}>
      <GenelOzet
        ozet={ozet}
        onFiltreChange={(f) => setFiltre((p) => ({ ...p, ...f }))}
      />

      <hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

      <KasaRaporu kasa={kasa} />

      <hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

      <GiderRaporu giderler={giderler} />
      <hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

<UrunRaporu urunler={urunler} />

<hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

<MasaRaporu masalar={masalar} />

<hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

<KategoriRaporu kategoriler={kategoriler} />

<hr style={{ margin: "32px 0", borderColor: "#e0c9a6" }} />

<BilardoRaporu bilardo={bilardo} />

    </div>
  );
}
