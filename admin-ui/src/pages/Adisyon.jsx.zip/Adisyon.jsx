import React, { useEffect, useMemo, useState } from "react";

// LocalStorage key'leri
const MASA_KEY = "mc_masalar";
const ADISYON_KEY = "mc_adisyonlar";
const URUN_KEY = "mc_urunler";
const MUSTERI_KEY = "mc_musteriler";
const BORC_KEY = "mc_borclar";

export default function Adisyon() {
  // --------------------------------------------------
  // GENEL STATE
  // --------------------------------------------------
  const [masaNo, setMasaNo] = useState("MASA 1");
  const [adisyon, setAdisyon] = useState(null);
  const [gecenSure, setGecenSure] = useState("00:00");

  // ÜRÜN / MENÜ
  const [urunler, setUrunler] = useState([]);
  const [aktifKategori, setAktifKategori] = useState("");
  const [seciliUrun, setSeciliUrun] = useState(null);
  const [adetPanelAcik, setAdetPanelAcik] = useState(false);
  const [adet, setAdet] = useState(1);

  // SİPARİŞ YEMEK manuel alan
  const [siparisYemekFiyat, setSiparisYemekFiyat] = useState("");
  const [siparisYemekNot, setSiparisYemekNot] = useState("");

  // TOPLAM / ÖDEME
  const [toplam, setToplam] = useState(0);
  const [indirimInput, setIndirimInput] = useState("");
  const [indirim, setIndirim] = useState(0);
  const [kalan, setKalan] = useState(0);

  const [aktifOdemeTipi, setAktifOdemeTipi] = useState("NAKIT"); // NAKIT, KART, HAVALE, HESAP
  const [odemeTutarInput, setOdemeTutarInput] = useState("");

  // HESABA YAZ / MÜŞTERİ
  const [musteriler, setMusteriler] = useState([]);
  const [seciliMusteriId, setSeciliMusteriId] = useState(null);
  const [yeniMusteriAdSoyad, setYeniMusteriAdSoyad] = useState("");
  const [yeniMusteriTelefon, setYeniMusteriTelefon] = useState("");
  const [yeniMusteriNot, setYeniMusteriNot] = useState("");

  const [borcTutarInput, setBorcTutarInput] = useState("");
  const [odemeSozuTarihi, setOdemeSozuTarihi] = useState("");

  const [hesabaYazModu, setHesabaYazModu] = useState(false);

  // ÖDEME SÖZÜ POPUP
  const [odemeSozuPopup, setOdemeSozuPopup] = useState(null);

  // ADİSYON KAPATILDI MESAJI
  const [kapanisMesaji, setKapanisMesaji] = useState("");

  // --------------------------------------------------
  // YARDIMCI: LocalStorage OKU / YAZ
  // --------------------------------------------------
  const okuJSON = (key, defaultValue) => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return defaultValue;
      return JSON.parse(raw);
    } catch {
      return defaultValue;
    }
  };

  const yazJSON = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
  };

  const odemeTipiLabel = (tip) => {
    switch (tip) {
      case "NAKIT":
        return "Nakit";
      case "KART":
        return "Kredi Kartı";
      case "HAVALE":
        return "Havale/EFT";
      case "HESABA_YAZ":
        return "Hesaba Yaz";
      default:
        return tip;
    }
  };

  // --------------------------------------------------
  // MASA NO ALMA (URL param ?masa=MASA%201 gibi)
  // --------------------------------------------------
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const masa = params.get("masa");
    if (masa) {
      setMasaNo(masa);
    } else {
      setMasaNo("MASA 1");
    }
  }, []);

  // --------------------------------------------------
  // ÜRÜNLERİ YÜKLE
  // --------------------------------------------------
  useEffect(() => {
    const list = okuJSON(URUN_KEY, []);
    setUrunler(Array.isArray(list) ? list : []);
  }, []);

  // Kategoriler (SİPARİŞ YEMEK hariç + manuel ekle)
  const kategoriler = useMemo(() => {
    const set = new Set();
    urunler.forEach((u) => {
      if (u.kategori) set.add(u.kategori);
    });
    set.add("SİPARİŞ YEMEK");
    const arr = Array.from(set);
    return arr.sort((a, b) => a.localeCompare(b, "tr"));
  }, [urunler]);

  useEffect(() => {
    if (!aktifKategori && kategoriler.length > 0) {
      setAktifKategori(kategoriler[0]);
    }
  }, [kategoriler, aktifKategori]);

  const filtreliUrunler = useMemo(() => {
    if (aktifKategori === "SİPARİŞ YEMEK") {
      // SİPARİŞ YEMEK için listede tek sanal kart gösterelim
      return [
        {
          id: "siparis-yemek",
          ad: "SİPARİŞ YEMEK",
          kategori: "SİPARİŞ YEMEK",
        },
      ];
    }
    return urunler.filter((u) => u.kategori === aktifKategori);
  }, [urunler, aktifKategori]);

  // --------------------------------------------------
  // ADİSYON YÜKLE / OLUŞTUR
  // --------------------------------------------------
  useEffect(() => {
    if (!masaNo) return;

    const tumAdisyonlar = okuJSON(ADISYON_KEY, []);
    let mevcut = tumAdisyonlar.find(
      (a) => a.masaNo === masaNo && a.durum !== "CLOSED"
    );

    if (!mevcut) {
      // Yeni adisyon
      mevcut = {
        id: Date.now().toString(),
        masaNo,
        acilisZamani: new Date().toISOString(),
        kapanisZamani: null,
        durum: "OPEN",
        kalemler: [], // {id, ad, kategori, adet, birimFiyat, toplam}
        odemeler: [], // {id, tip, tutar}
        indirim: 0,
        hesabaYazKayitlari: [], // borç linkleri vb.
      };
      tumAdisyonlar.push(mevcut);
      yazJSON(ADISYON_KEY, tumAdisyonlar);
    }

    setAdisyon(mevcut);
  }, [masaNo]);

  // --------------------------------------------------
  // ADİSYON DEĞİŞTİĞİNDE TOPLAM / KALAN HESAPLA
  // --------------------------------------------------
  useEffect(() => {
    if (!adisyon) return;

    const satirToplam = (adisyon.kalemler || []).reduce(
      (sum, k) => sum + (Number(k.toplam) || 0),
      0
    );
    const odemelerToplam = (adisyon.odemeler || []).reduce(
      (sum, o) => sum + (Number(o.tutar) || 0),
      0
    );

    setToplam(satirToplam);
    const kalanTutar = Math.max(
      satirToplam - (indirim || 0) - odemelerToplam,
      0
    );
    setKalan(kalanTutar);

    // Indirimi adisyon içinde de saklayalım
    const guncel = { ...adisyon, indirim: indirim || 0 };
    setAdisyon(guncel);

    // LocalStorage'a yaz
    const tum = okuJSON(ADISYON_KEY, []);
    const idx = tum.findIndex((a) => a.id === guncel.id);
    if (idx !== -1) {
      tum[idx] = guncel;
      yazJSON(ADISYON_KEY, tum);
    }
  }, [
    adisyon?.id,
    JSON.stringify(adisyon?.kalemler),
    JSON.stringify(adisyon?.odemeler),
    indirim,
  ]);

  // --------------------------------------------------
  // GEÇEN SÜRE HESABI
  // --------------------------------------------------
  useEffect(() => {
    if (!adisyon || !adisyon.acilisZamani) return;

    const hesapla = () => {
      const acilis = new Date(adisyon.acilisZamani).getTime();
      const now = Date.now();
      const diffMs = Math.max(now - acilis, 0);
      const diffDakika = Math.floor(diffMs / 60000);
      const saat = String(Math.floor(diffDakika / 60)).padStart(2, "0");
      const dakika = String(diffDakika % 60).padStart(2, "0");
      setGecenSure(`${saat}:${dakika}`);
    };

    hesapla();
    const timer = setInterval(hesapla, 60 * 1000);
    return () => clearInterval(timer);
  }, [adisyon?.acilisZamani]);

  // --------------------------------------------------
  // MÜŞTERİ / BORÇ VERİLERİNİ YÜKLE
  // --------------------------------------------------
  useEffect(() => {
    const mList = okuJSON(MUSTERI_KEY, []);
    setMusteriler(Array.isArray(mList) ? mList : []);
  }, []);

  // --------------------------------------------------
  // ÖDEME SÖZÜ POPUP KONTROLÜ
  // --------------------------------------------------
  useEffect(() => {
    const borclar = okuJSON(BORC_KEY, []);
    if (!Array.isArray(borclar)) return;

    const todayStr = new Date().toISOString().split("T")[0];

    const bekleyen = borclar.find(
      (b) =>
        b.odemeSozu &&
        !b.hatirlatildi &&
        b.odemeSozu <= todayStr // Bugün veya geçmiş
    );

    if (bekleyen) {
      const musteri = (okuJSON(MUSTERI_KEY, []) || []).find(
        (m) => m.id === bekleyen.musteriId
      );
      setOdemeSozuPopup({
        borcId: bekleyen.id,
        musteriAd: musteri ? musteri.adSoyad : "Bilinmeyen Müşteri",
        odemeSozu: bekleyen.odemeSozu,
      });
    }
  }, []);

  const odemeSozuPopupKapat = () => {
    if (!odemeSozuPopup) return;
    const borclar = okuJSON(BORC_KEY, []);
    const idx = borclar.findIndex((b) => b.id === odemeSozuPopup.borcId);
    if (idx !== -1) {
      borclar[idx].hatirlatildi = true;
      yazJSON(BORC_KEY, borclar);
    }
    setOdemeSozuPopup(null);
  };

  const odemeSozuPopupDetayaGit = () => {
    odemeSozuPopupKapat();
    // Müşteri Borç Raporu sayfasına yönlendirme
    window.location.href = "/musteri-borc-raporu";
  };

  // --------------------------------------------------
  // ÜRÜNE TIKLAYINCA ADET PANELİ AÇILSIN
  // (KURAL: sadece ürüne tıklanınca aktif olur)
  // --------------------------------------------------
  const urunTikla = (urun) => {
    setSeciliUrun(urun);
    setAdet(1);
    setAdetPanelAcik(true);

    if (urun.kategori === "SİPARİŞ YEMEK") {
      // SİPARİŞ YEMEK ise alttaki manuel panel kullanılacak
      setSiparisYemekFiyat("");
      setSiparisYemekNot("");
    }
  };

  const adetArttir = () => setAdet((a) => a + 1);
  const adetAzalt = () => setAdet((a) => (a > 1 ? a - 1 : 1));

  const adetPanelEkle = () => {
    if (!seciliUrun || !adisyon) return;

    let birimFiyat = Number(seciliUrun.satis || seciliUrun.fiyat || 0);

    // SİPARİŞ YEMEK ise manuel fiyat zorunlu ve adet = 1
    let adetToUse = adet;
    if (seciliUrun.kategori === "SİPARİŞ YEMEK") {
      const f = Number(siparisYemekFiyat);
      if (!f || f <= 0) {
        alert("SİPARİŞ YEMEK için fiyat giriniz.");
        return;
      }
      birimFiyat = f;
      adetToUse = 1;
    }

    const yeniKalem = {
      id: Date.now().toString(),
      ad: seciliUrun.ad || seciliUrun.urunAd || "Ürün",
      kategori: seciliUrun.kategori || "",
      adet: adetToUse,
      birimFiyat,
      toplam: birimFiyat * adetToUse,
      not:
        seciliUrun.kategori === "SİPARİŞ YEMEK"
          ? siparisYemekNot || ""
          : "",
    };

    const guncel = {
      ...adisyon,
      kalemler: [...(adisyon.kalemler || []), yeniKalem],
    };
    setAdisyon(guncel);

    // ADET panelini kapa
    setAdetPanelAcik(false);
    setSeciliUrun(null);
  };

  // --------------------------------------------------
  // SATIR / ADET SİLME
  // --------------------------------------------------
  const satirTamSil = (kalemId) => {
    if (!adisyon) return;
    const yeniKalemler = (adisyon.kalemler || []).filter(
      (k) => k.id !== kalemId
    );
    const guncel = { ...adisyon, kalemler: yeniKalemler };
    setAdisyon(guncel);
  };

  const satirAdetAzalt = (kalemId) => {
    if (!adisyon) return;

    const yeniKalemler = (adisyon.kalemler || [])
      .map((k) => {
        if (k.id !== kalemId) return k;
        const yeniAdet = k.adet > 1 ? k.adet - 1 : 0;
        if (yeniAdet <= 0) return null;
        const birim = Number(k.birimFiyat) || 0;
        return {
          ...k,
          adet: yeniAdet,
          toplam: birim * yeniAdet,
        };
      })
      .filter(Boolean);

    const guncel = { ...adisyon, kalemler: yeniKalemler };
    setAdisyon(guncel);
  };

  const satirAdetArtir = (kalemId) => {
    if (!adisyon) return;

    const yeniKalemler = (adisyon.kalemler || []).map((k) => {
      if (k.id !== kalemId) return k;
      const birim = Number(k.birimFiyat) || 0;
      const yeniAdet = (k.adet || 0) + 1;
      return {
        ...k,
        adet: yeniAdet,
        toplam: birim * yeniAdet,
      };
    });

    const guncel = { ...adisyon, kalemler: yeniKalemler };
    setAdisyon(guncel);
  };

  // --------------------------------------------------
  // İNDİRİM (manuel, ENTER ile aktif olur)
  // --------------------------------------------------
  const indirimKeyDown = (e) => {
    if (e.key === "Enter") {
      const val = Number(indirimInput) || 0;
      setIndirim(val);
    }
  };

  // --------------------------------------------------
  // ÖDEME EKLE (NAKİT / KART / HAVALE)
  // --------------------------------------------------
  const odemeEkle = () => {
    if (!adisyon) return;
    if (aktifOdemeTipi === "HESAP") {
      // HESABA YAZ için ödeme eklemiyoruz, müşteri ekranı kullanılıyor
      setHesabaYazModu(true);
      setBorcTutarInput(String(kalan || 0));
      return;
    }

    let tutar = Number(odemeTutarInput);

    // Input boş veya 0 ise KALAN'ın tamamını tahsil et
    if (!odemeTutarInput || tutar <= 0) {
      if (kalan <= 0) {
        alert("Tahsil edilecek kalan tutar yok.");
        return;
      }
      tutar = kalan;
    }

    const yeniOdeme = {
      id: Date.now().toString(),
      tip: aktifOdemeTipi, // NAKIT / KART / HAVALE
      tutar,
    };

    const guncel = {
      ...adisyon,
      odemeler: [...(adisyon.odemeler || []), yeniOdeme],
    };
    setAdisyon(guncel);
    setOdemeTutarInput("");
  };

  const odemeTutarKeyDown = (e) => {
    if (e.key === "Enter") {
      odemeEkle();
    }
  };

  // --------------------------------------------------
  // ÖDEME YAP BUTONU
  // --------------------------------------------------
  const odemeYap = () => {
    if (!adisyon) return;

    if (aktifOdemeTipi === "HESAP") {
      // HESABA YAZ – müşteri ekranını aç
      setHesabaYazModu(true);
      setBorcTutarInput(String(kalan || 0));
      return;
    }

    // Normal ödeme ise
    if (kalan === 0) {
      // KURAL: Adisyon kapanışı sadece ÖDEME YAP + kalan 0 ise
      const guncel = {
        ...adisyon,
        durum: "CLOSED",
        kapanisZamani: new Date().toISOString(),
      };
      setAdisyon(guncel);

      // LocalStorage güncelle
      const tum = okuJSON(ADISYON_KEY, []);
      const idx = tum.findIndex((a) => a.id === guncel.id);
      if (idx !== -1) {
        tum[idx] = guncel;
        yazJSON(ADISYON_KEY, tum);
      }

      // Masa durumunu yeşile çevir (basit mantık: dolu=false)
      const masalar = okuJSON(MASA_KEY, []);
      const mIdx = masalar.findIndex(
        (m) => m.ad === masaNo || m.masaNo === masaNo
      );
      if (mIdx !== -1) {
        masalar[mIdx] = {
          ...masalar[mIdx],
          dolu: false,
          acikAdisyonId: null,
        };
        yazJSON(MASA_KEY, masalar);
      }

      // Popup yok, sayfanın altında mesaj + 2 sn sonra MASALAR
      setKapanisMesaji("ADİSYON KAPATILDI");
      setTimeout(() => {
        window.location.href = "/masalar";
      }, 2000);
    } else {
      alert("Adisyonu kapatmak için kalan tutar 0 olmalıdır.");
    }
  };

  // --------------------------------------------------
  // MASAYA DÖN BUTONU
  // --------------------------------------------------
  const masayaDon = () => {
    window.location.href = "/masalar";
  };

  // --------------------------------------------------
  // HESABA YAZ KAYDET
  // --------------------------------------------------
  const seciliMusteri = useMemo(() => {
    return musteriler.find((m) => m.id === seciliMusteriId) || null;
  }, [musteriler, seciliMusteriId]);

  const mevcutBorcBilgisi = useMemo(() => {
    if (!seciliMusteri) return { toplamBorc: 0, toplamOdeme: 0, kalan: 0 };
    const tb = Number(seciliMusteri.toplamBorc || 0);
    const to = Number(seciliMusteri.toplamOdeme || 0);
    return {
      toplamBorc: tb,
      toplamOdeme: to,
      kalan: tb - to,
    };
  }, [seciliMusteri]);

  const hesabaYazKaydet = () => {
    if (!adisyon) return;

    let borcTutar = Number(borcTutarInput);
    if (!borcTutar || borcTutar <= 0) {
      alert("Borç tutarı giriniz.");
      return;
    }

    if (!odemeSozuTarihi) {
      alert("Ödeme sözü tarihini giriniz.");
      return;
    }

    let guncelMusteriler = [...musteriler];
    let musteriId = seciliMusteriId;

    if (!musteriId) {
      // Yeni müşteri oluştur
      if (!yeniMusteriAdSoyad) {
        alert("Yeni müşteri için Ad Soyad giriniz.");
        return;
      }
      const yeniId = Date.now().toString();
      const yeniMusteri = {
        id: yeniId,
        adSoyad: yeniMusteriAdSoyad,
        telefon: yeniMusteriTelefon,
        not: yeniMusteriNot,
        toplamBorc: borcTutar,
        toplamOdeme: 0,
      };
      guncelMusteriler.push(yeniMusteri);
      musteriId = yeniId;
    } else {
      // Var olan müşterinin toplam borcunu arttır
      guncelMusteriler = guncelMusteriler.map((m) => {
        if (m.id !== musteriId) return m;
        const eskiBorc = Number(m.toplamBorc || 0);
        return {
          ...m,
          toplamBorc: eskiBorc + borcTutar,
        };
      });
    }

    // Borç kaydı
    const borclar = okuJSON(BORC_KEY, []);
    const yeniBorc = {
      id: Date.now().toString(),
      musteriId,
      masaNo,
      adisyonId: adisyon.id,
      tutar: borcTutar,
      acilisZamani: adisyon.acilisZamani,
      kapanisZamani: adisyon.kapanisZamani,
      odemeSozu: odemeSozuTarihi,
      hatirlatildi: false,
      hareketler: [
        {
          tip: "BORÇ EKLENDİ",
          tutar: borcTutar,
          tarih: new Date().toISOString(),
          aciklama: `Hesaba Yaz - ${masaNo}`,
        },
      ],
    };
    borclar.push(yeniBorc);
    yazJSON(BORC_KEY, borclar);

    // HESABA_YAZ ödeme satırı ekle
    const yeniOdeme = {
      id: `hy_${Date.now().toString()}`,
      tip: "HESABA_YAZ",
      tutar: borcTutar,
    };

    const guncelAdisyon = {
      ...adisyon,
      hesabaYazKayitlari: [
        ...(adisyon.hesabaYazKayitlari || []),
        { borcId: yeniBorc.id, musteriId },
      ],
      odemeler: [...(adisyon.odemeler || []), yeniOdeme],
    };
    setAdisyon(guncelAdisyon);

    // Müşteri listesi yaz
    yazJSON(MUSTERI_KEY, guncelMusteriler);
    setMusteriler(guncelMusteriler);

    alert("Borç kaydedildi. (Hesaba Yaz) – Adisyon kapatılmadı.");
    setHesabaYazModu(false);
  };

  // --------------------------------------------------
  // RENDER BAŞLIYOR
  // --------------------------------------------------
  if (!adisyon) {
    return <div>Adisyon yükleniyor...</div>;
  }

  return (
    <div
      style={{
        display: "flex",
        height: "100vh",
        background: "#f5e7d0", // bej
        color: "#4b2e05", // kahve
        padding: "10px",
        boxSizing: "border-box",
        gap: "10px",
      }}
    >
      {/* SOL PANEL – ÖDEME */}
      <div
        style={{
          width: "22%",
          background: "#f9ecd8",
          borderRadius: "10px",
          padding: "10px",
          display: "flex",
          flexDirection: "column",
          boxSizing: "border-box",
        }}
      >
        <h2 style={{ marginTop: 0, marginBottom: "10px" }}>ÖDEME</h2>

        {/* ÖDEME TİPLERİ */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
          {[
            { kod: "NAKIT", etiket: "Nakit" },
            { kod: "KART", etiket: "Kredi Kartı" },
            { kod: "HAVALE", etiket: "Havale/EFT" },
            { kod: "HESAP", etiket: "Hesaba Yaz" },
          ].map((o) => (
            <button
              key={o.kod}
              onClick={() => {
                setAktifOdemeTipi(o.kod);
                if (o.kod === "HESAP") {
                  setHesabaYazModu(true);
                  setBorcTutarInput(String(kalan || 0));
                }
              }}
              style={{
                flex: "1 1 45%",
                padding: "8px",
                borderRadius: "6px",
                border:
                  aktifOdemeTipi === o.kod
                    ? "2px solid #c0392b"
                    : "1px solid #bfa37d",
                background:
                  aktifOdemeTipi === o.kod ? "#f4d1c6" : "#fdf4e4",
                cursor: "pointer",
              }}
            >
              {o.etiket}
            </button>
          ))}
        </div>

        {/* ÖDEME TUTARI */}
        {aktifOdemeTipi !== "HESAP" && (
          <>
            <div style={{ marginTop: "10px" }}>
              <label>Tutar</label>
              <input
                type="number"
                value={odemeTutarInput}
                onChange={(e) => setOdemeTutarInput(e.target.value)}
                onKeyDown={odemeTutarKeyDown}
                style={{
                  width: "100%",
                  padding: "6px",
                  borderRadius: "6px",
                  border: "1px solid #bfa37d",
                  marginTop: "4px",
                }}
              />
              <div
                style={{
                  fontSize: "11px",
                  marginTop: "4px",
                  color: "#7f8c8d",
                }}
              >
                Boş bırakılırsa KALAN tutarın tamamı tahsil edilir.
              </div>
            </div>
            <button
              onClick={odemeEkle}
              style={{
                marginTop: "8px",
                padding: "8px",
                borderRadius: "6px",
                border: "none",
                background: "#4b2e05",
                color: "#fff",
                cursor: "pointer",
              }}
            >
              ÖDEME EKLE
            </button>
          </>
        )}

        {/* İNDİRİM */}
        <div style={{ marginTop: "12px" }}>
          <label>İndirim (Enter ile uygula)</label>
          <input
            type="number"
            value={indirimInput}
            onChange={(e) => setIndirimInput(e.target.value)}
            onKeyDown={indirimKeyDown}
            style={{
              width: "100%",
              padding: "6px",
              borderRadius: "6px",
              border: "1px solid #bfa37d",
              marginTop: "4px",
            }}
          />
          <div style={{ fontSize: "12px", marginTop: "4px" }}>
            Uygulanan indirim: <b>{indirim.toFixed(2)} ₺</b>
          </div>
        </div>

        {/* TOPLAM / KALAN */}
        <div
          style={{
            marginTop: "12px",
            padding: "8px",
            borderRadius: "6px",
            background: "#fdf4e4",
            border: "1px solid #bfa37d",
          }}
        >
          <div>
            Toplam: <b>{toplam.toFixed(2)} ₺</b>
          </div>
          <div>
            Kalan:{" "}
              <b style={{ color: kalan === 0 ? "#4CAF50" : "#c0392b" }}>
              {kalan.toFixed(2)} ₺
            </b>
          </div>
        </div>

        {/* BUTONLAR */}
        <div
          style={{
            marginTop: "auto",
            display: "flex",
            flexDirection: "column",
            gap: "8px",
          }}
        >
          <button
            onClick={odemeYap}
            style={{
              padding: "10px",
              borderRadius: "8px",
              border: "none",
              background: "#27ae60",
              color: "#fff",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            ÖDEME YAP
          </button>
          <button
            onClick={masayaDon}
            style={{
              padding: "8px",
              borderRadius: "8px",
              border: "1px solid #bfa37d",
              background: "#fdf4e4",
              cursor: "pointer",
            }}
          >
            MASAYA DÖN
          </button>
        </div>
      </div>

      {/* ORTA PANEL – ADİSYON / HESABA YAZ */}
      <div
        style={{
          flex: 1,
          background: "#fff7e6",
          borderRadius: "10px",
          padding: "10px",
          display: "flex",
          flexDirection: "column",
          boxSizing: "border-box",
        }}
      >
        {/* ÜST BİLGİLER */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "8px",
          }}
        >
          <div>
            <div>
              Masa: <b>{masaNo}</b>
            </div>
            <div style={{ fontSize: "12px" }}>
              Açılış:{" "}
              {adisyon.acilisZamani
                ? new Date(adisyon.acilisZamani).toLocaleString()
                : "-"}
            </div>
          </div>
          <div>
            Geçen Süre: <b>{gecenSure}</b>
          </div>
        </div>

        {!hesabaYazModu && (
          <>
            {/* ADİSYON LİSTESİ */}
            <div
              style={{
                flex: 1,
                overflow: "auto",
                border: "1px solid #ecd3a5",
                borderRadius: "6px",
                background: "#fff",
              }}
            >
              <table
                style={{
                  width: "100%",
                  borderCollapse: "collapse",
                  fontSize: "14px",
                }}
              >
                <thead>
                  <tr
                    style={{
                      background: "#f5e7d0",
                      position: "sticky",
                      top: 0,
                    }}
                  >
                    <th
                      style={{
                        padding: "6px",
                        borderBottom: "1px solid #ecd3a5",
                      }}
                    >
                      Ürün
                    </th>
                    <th
                      style={{
                        padding: "6px",
                        borderBottom: "1px solid #ecd3a5",
                      }}
                    >
                      Adet
                    </th>
                    <th
                      style={{
                        padding: "6px",
                        borderBottom: "1px solid #ecd3a5",
                      }}
                    >
                      Birim
                    </th>
                    <th
                      style={{
                        padding: "6px",
                        borderBottom: "1px solid #ecd3a5",
                      }}
                    >
                      Toplam
                    </th>
                    <th
                      style={{
                        padding: "6px",
                        borderBottom: "1px solid #ecd3a5",
                      }}
                    >
                      İşlem
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {(adisyon.kalemler || []).length === 0 && indirim === 0 && (
                    <tr>
                      <td
                        colSpan={5}
                        style={{
                          textAlign: "center",
                          padding: "10px",
                          fontStyle: "italic",
                        }}
                      >
                        Henüz ürün eklenmemiş.
                      </td>
                    </tr>
                  )}

                  {(adisyon.kalemler || []).map((k) => (
                    <tr key={k.id}>
                      <td
                        style={{
                          borderBottom: "1px solid #f0e0c4",
                          padding: "4px 6px",
                        }}
                      >
                        {k.kategori === "SİPARİŞ YEMEK" ? "SİPARİŞ YEMEK" : k.ad}
                        {k.not ? (
                          <div
                            style={{ fontSize: "11px", color: "#7f8c8d" }}
                          >
                            Not: {k.not}
                          </div>
                        ) : null}
                      </td>
                      <td
                        style={{
                          borderBottom: "1px solid #f0e0c4",
                          padding: "4px 6px",
                          textAlign: "center",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: "4px",
                          }}
                        >
                          <button
                            onClick={() => satirAdetAzalt(k.id)}
                            style={{
                              padding: "2px 6px",
                              borderRadius: "4px",
                              border: "1px solid #bfa37d",
                              background: "#fdf4e4",
                              cursor: "pointer",
                              fontSize: "11px",
                            }}
                          >
                            -
                          </button>
                          <span>{k.adet}</span>
                          <button
                            onClick={() => satirAdetArtir(k.id)}
                            style={{
                              padding: "2px 6px",
                              borderRadius: "4px",
                              border: "1px solid #bfa37d",
                              background: "#fdf4e4",
                              cursor: "pointer",
                              fontSize: "11px",
                            }}
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td
                        style={{
                          borderBottom: "1px solid #f0e0c4",
                          padding: "4px 6px",
                          textAlign: "right",
                        }}
                      >
                        {Number(k.birimFiyat || 0).toFixed(2)} ₺
                      </td>
                      <td
                        style={{
                          borderBottom: "1px solid #f0e0c4",
                          padding: "4px 6px",
                          textAlign: "right",
                        }}
                      >
                        {Number(k.toplam || 0).toFixed(2)} ₺
                      </td>
                      <td
                        style={{
                          borderBottom: "1px solid #f0e0c4",
                          padding: "4px 6px",
                          textAlign: "center",
                        }}
                      >
                        <button
                          onClick={() => satirTamSil(k.id)}
                          style={{
                            padding: "2px 6px",
                            borderRadius: "4px",
                            border: "1px solid #c0392b",
                            background: "#fbe4e0",
                            color: "#c0392b",
                            cursor: "pointer",
                            fontSize: "11px",
                          }}
                        >
                          Satırı Sil
                        </button>
                      </td>
                    </tr>
                  ))}

                  {/* İNDİRİM SATIRI */}
                  {indirim > 0 && (
                    <tr>
                      <td
                        style={{
                          padding: "4px 6px",
                          borderTop: "1px solid #f0e0c4",
                          fontWeight: "bold",
                        }}
                      >
                        İndirim (-)
                      </td>
                      <td />
                      <td />
                      <td
                        style={{
                          padding: "4px 6px",
                          textAlign: "right",
                          color: "#c0392b",
                          fontWeight: "bold",
                        }}
                      >
                        -{indirim.toFixed(2)} ₺
                      </td>
                      <td />
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* ALT TOPLAM PANEL */}
            <div
              style={{
                marginTop: "6px",
                padding: "6px 8px",
                borderRadius: "6px",
                background: "#f5e7d0",
              }}
            >
              Adisyon Toplamı:{" "}
              <b>{toplam.toFixed(2)} ₺</b> | İndirim:{" "}
              <b>{indirim.toFixed(2)} ₺</b> | Kalan:{" "}
              <b style={{ color: kalan === 0 ? "#27ae60" : "#c0392b" }}>
                {kalan.toFixed(2)} ₺
              </b>
            </div>

            {/* ADİSYON KAPATILDI MESAJI */}
            {kapanisMesaji && (
              <div
                style={{
                  marginTop: "6px",
                  padding: "8px",
                  borderRadius: "6px",
                  background: "#d4edda",
                  color: "#155724",
                  textAlign: "center",
                  fontWeight: "bold",
                }}
              >
                {kapanisMesaji}
              </div>
            )}

            {/* ÖDEMELER BÖLÜMÜ */}
            <div
              style={{
                marginTop: "8px",
                padding: "6px 8px",
                borderRadius: "6px",
                background: "#fff",
                border: "1px solid #ecd3a5",
              }}
            >
              <div
                style={{
                  fontWeight: "bold",
                  marginBottom: "4px",
                }}
              >
                Ödemeler
              </div>
              {(adisyon.odemeler || []).length === 0 ? (
                <div
                  style={{
                    fontSize: "13px",
                    fontStyle: "italic",
                    color: "#7f8c8d",
                  }}
                >
                  Henüz ödeme yapılmamış.
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {adisyon.odemeler.map((o) => (
                    <div
                      key={o.id}
                      style={{
                        padding: "4px 6px",
                        borderRadius: "4px",
                        background: "#e8f8f1",
                        color: "#1e8449",
                        fontSize: "13px",
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <span>{odemeTipiLabel(o.tip)}</span>
                      <span>{Number(o.tutar || 0).toFixed(2)} ₺</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* ADET PANELİ (ÜRÜNE TIKLANINCA) */}
            {adetPanelAcik && seciliUrun && (
              <div
                style={{
                  marginTop: "8px",
                  padding: "8px",
                  borderRadius: "6px",
                  background: "#fff",
                  border: "1px solid #ecd3a5",
                }}
              >
                <div style={{ marginBottom: "4px" }}>
                  Seçili Ürün:{" "}
                  <b>
                    {seciliUrun.kategori === "SİPARİŞ YEMEK"
                      ? "SİPARİŞ YEMEK"
                      : seciliUrun.ad || seciliUrun.urunAd}
                  </b>
                </div>

                {/* SİPARİŞ YEMEK dışındakilerde adet arttır/azalt */}
                {seciliUrun.kategori !== "SİPARİŞ YEMEK" && (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      marginBottom: "6px",
                    }}
                  >
                    <button
                      onClick={adetAzalt}
                      style={{
                        padding: "4px 10px",
                        borderRadius: "6px",
                        border: "1px solid #bfa37d",
                        background: "#fdf4e4",
                        cursor: "pointer",
                      }}
                    >
                      -
                    </button>
                    <div style={{ minWidth: "40px", textAlign: "center" }}>
                      <b>{adet}</b>
                    </div>
                    <button
                      onClick={adetArttir}
                      style={{
                        padding: "4px 10px",
                        borderRadius: "6px",
                        border: "1px solid #bfa37d",
                        background: "#fdf4e4",
                        cursor: "pointer",
                      }}
                    >
                      +
                    </button>
                  </div>
                )}

                {seciliUrun.kategori === "SİPARİŞ YEMEK" && (
                  <div
                    style={{
                      marginBottom: "6px",
                      fontSize: "12px",
                      color: "#7f8c8d",
                    }}
                  >
                    SİPARİŞ YEMEK satırı her zaman tek adet (1) olarak eklenir.
                  </div>
                )}

                {/* SİPARİŞ YEMEK ise alt alan */}
                {seciliUrun.kategori === "SİPARİŞ YEMEK" && (
                  <div style={{ marginBottom: "6px" }}>
                    <div style={{ marginBottom: "4px" }}>
                      SİPARİŞ YEMEK Fiyatı
                    </div>
                    <input
                      type="number"
                      value={siparisYemekFiyat}
                      onChange={(e) => setSiparisYemekFiyat(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "6px",
                        borderRadius: "6px",
                        border: "1px solid #bfa37d",
                        marginBottom: "4px",
                      }}
                    />
                    <div style={{ marginBottom: "2px", fontSize: "12px" }}>
                      Not (opsiyonel)
                    </div>
                    <input
                      type="text"
                      value={siparisYemekNot}
                      onChange={(e) => setSiparisYemekNot(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "6px",
                        borderRadius: "6px",
                        border: "1px solid #bfa37d",
                      }}
                    />
                  </div>
                )}

                <button
                  onClick={adetPanelEkle}
                  style={{
                    marginTop: "4px",
                    padding: "6px 10px",
                    borderRadius: "6px",
                    border: "none",
                    background: "#4b2e05",
                    color: "#fff",
                    cursor: "pointer",
                  }}
                >
                  ADİSYONA EKLE
                </button>
              </div>
            )}
          </>
        )}

        {/* HESABA YAZ MODU */}
        {hesabaYazModu && (
          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "row",
              gap: "10px",
              marginTop: "8px",
            }}
          >
            {/* MÜŞTERİ LİSTESİ */}
            <div
              style={{
                width: "45%",
                border: "1px solid #ecd3a5",
                borderRadius: "6px",
                background: "#fff",
                overflow: "auto",
              }}
            >
              <div
                style={{
                  padding: "6px",
                  borderBottom: "1px solid #ecd3a5",
                  background: "#f5e7d0",
                  fontWeight: "bold",
                }}
              >
                Müşteri Seç
              </div>
              {musteriler.length === 0 && (
                <div style={{ padding: "8px", fontSize: "13px" }}>
                  Kayıtlı müşteri yok. Sağ taraftan yeni müşteri ekleyin.
                </div>
              )}
              {musteriler.map((m) => {
                const kalanB =
                  (Number(m.toplamBorc || 0) -
                    Number(m.toplamOdeme || 0)) || 0;
                return (
                  <div
                    key={m.id}
                    onClick={() => setSeciliMusteriId(m.id)}
                    style={{
                      padding: "6px 8px",
                      borderBottom: "1px solid #f0e0c4",
                      cursor: "pointer",
                      background:
                        seciliMusteriId === m.id ? "#f4d1c6" : "transparent",
                    }}
                  >
                    <div style={{ fontWeight: "bold" }}>{m.adSoyad}</div>
                    <div style={{ fontSize: "11px" }}>
                      Kalan Borç: {kalanB.toFixed(2)} ₺
                    </div>
                  </div>
                );
              })}
            </div>

            {/* BORÇ FORMU */}
            <div
              style={{
                flex: 1,
                border: "1px solid #ecd3a5",
                borderRadius: "6px",
                background: "#fff",
                padding: "8px",
                boxSizing: "border-box",
              }}
            >
              <h3 style={{ marginTop: 0 }}>Hesaba Yaz</h3>

              {seciliMusteri && (
                <div
                  style={{
                    padding: "6px",
                    marginBottom: "8px",
                    borderRadius: "6px",
                    background: "#fdf4e4",
                    fontSize: "13px",
                  }}
                >
                  <div>
                    Seçili Müşteri: <b>{seciliMusteri.adSoyad}</b>
                  </div>
                  <div>
                    Mevcut Borç:{" "}
                    <b>{mevcutBorcBilgisi.kalan.toFixed(2)} ₺</b>
                  </div>
                </div>
              )}

              {!seciliMusteri && (
                <div
                  style={{
                    padding: "6px",
                    marginBottom: "8px",
                    borderRadius: "6px",
                    background: "#fdf4e4",
                    fontSize: "13px",
                  }}
                >
                  Yeni müşteri kaydı yapılacak.
                </div>
              )}

              {!seciliMusteri && (
                <>
                  <div style={{ marginBottom: "4px" }}>Ad Soyad</div>
                  <input
                    type="text"
                    value={yeniMusteriAdSoyad}
                    onChange={(e) => setYeniMusteriAdSoyad(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "6px",
                      borderRadius: "6px",
                      border: "1px solid #bfa37d",
                      marginBottom: "6px",
                    }}
                  />
                  <div style={{ marginBottom: "4px" }}>Telefon</div>
                  <input
                    type="text"
                    value={yeniMusteriTelefon}
                    onChange={(e) => setYeniMusteriTelefon(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "6px",
                      borderRadius: "6px",
                      border: "1px solid #bfa37d",
                      marginBottom: "6px",
                    }}
                  />
                  <div style={{ marginBottom: "4px" }}>Not</div>
                  <input
                    type="text"
                    value={yeniMusteriNot}
                    onChange={(e) => setYeniMusteriNot(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "6px",
                      borderRadius: "6px",
                      border: "1px solid #bfa37d",
                      marginBottom: "8px",
                    }}
                  />
                </>
              )}

              <div style={{ marginBottom: "4px" }}>Borç Tutarı</div>
              <input
                type="number"
                value={borcTutarInput}
                onChange={(e) => setBorcTutarInput(e.target.value)}
                style={{
                  width: "100%",
                  padding: "6px",
                  borderRadius: "6px",
                  border: "1px solid #bfa37d",
                  marginBottom: "6px",
                }}
              />

              <div style={{ marginBottom: "4px" }}>Ödeme Sözü Tarihi</div>
              <input
                type="date"
                value={odemeSozuTarihi}
                onChange={(e) => setOdemeSozuTarihi(e.target.value)}
                style={{
                  width: "100%",
                  padding: "6px",
                  borderRadius: "6px",
                  border: "1px solid #bfa37d",
                  marginBottom: "10px",
                }}
              />

              <button
                onClick={hesabaYazKaydet}
                style={{
                  padding: "8px 10px",
                  borderRadius: "6px",
                  border: "none",
                  background: "#4b2e05",
                  color: "#fff",
                  cursor: "pointer",
                  marginRight: "8px",
                }}
              >
                BORÇ KAYDET
              </button>
              <button
                onClick={() => setHesabaYazModu(false)}
                style={{
                  padding: "8px 10px",
                  borderRadius: "6px",
                  border: "1px solid #bfa37d",
                  background: "#fdf4e4",
                  cursor: "pointer",
                }}
              >
                İPTAL
              </button>
            </div>
          </div>
        )}
      </div>

      {/* SAĞ PANEL – MENÜ */}
      <div
        style={{
          width: "26%",
          background: "#f9ecd8",
          borderRadius: "10px",
          padding: "10px",
          display: "flex",
          flexDirection: "column",
          boxSizing: "border-box",
        }}
      >
        <h2 style={{ marginTop: 0, marginBottom: "8px" }}>MENÜ</h2>

        {/* KATEGORİ SEÇİMİ */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "6px",
            marginBottom: "8px",
            maxHeight: "80px",
            overflow: "auto",
          }}
        >
          {kategoriler.map((kat) => (
            <button
              key={kat}
              onClick={() => {
                setAktifKategori(kat);
                setSeciliUrun(null);
                setAdetPanelAcik(false);
              }}
              style={{
                padding: "4px 8px",
                borderRadius: "6px",
                border:
                  aktifKategori === kat
                    ? "2px solid #c0392b"
                    : "1px solid #bfa37d",
                background:
                  aktifKategori === kat ? "#f4d1c6" : "#fdf4e4",
                cursor: "pointer",
                fontSize: "12px",
              }}
            >
              {kat}
            </button>
          ))}
        </div>

        {/* ÜRÜN LİSTESİ */}
        <div
          style={{
            flex: 1,
            overflow: "auto",
            borderRadius: "6px",
          }}
        >
          {filtreliUrunler.length === 0 && (
            <div
              style={{
                padding: "8px",
                fontSize: "13px",
                fontStyle: "italic",
              }}
            >
              Bu kategoride ürün bulunamadı.
            </div>
          )}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
              gap: "8px",
            }}
          >
            {filtreliUrunler.map((u) => (
              <div
                key={u.id}
                onClick={() => urunTikla(u)}
                style={{
                  padding: "8px",
                  borderRadius: "8px",
                  background:
                    u.kategori === "SİPARİŞ YEMEK" ? "#fbe4e0" : "#fff",
                  border:
                    u.kategori === "SİPARİŞ YEMEK"
                      ? "2px solid #c0392b"
                      : "1px solid #bfa37d",
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                  fontSize: "13px",
                }}
              >
                <div style={{ fontWeight: "bold", marginBottom: "4px" }}>
                  {u.kategori === "SİPARİŞ YEMEK"
                    ? "SİPARİŞ YEMEK"
                    : u.ad || u.urunAd}
                </div>
                {u.kategori !== "SİPARİŞ YEMEK" && (
                  <div style={{ fontSize: "12px" }}>
                    {(Number(u.satis || u.fiyat || 0) || 0).toFixed(2)} ₺
                  </div>
                )}
                {u.kategori === "SİPARİŞ YEMEK" && (
                  <div
                    style={{
                      fontSize: "11px",
                      color: "#c0392b",
                      marginTop: "2px",
                    }}
                  >
                    Fiyat adisyonda manuel girilir.
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ÖDEME SÖZÜ POPUP */}
      {odemeSozuPopup && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(0,0,0,0.25)",
          }}
        >
          <div
            style={{
              width: "320px",
              background: "#fff7e6",
              borderRadius: "10px",
              boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
              padding: "12px",
              boxSizing: "border-box",
            }}
          >
            <h3
              style={{
                marginTop: 0,
                marginBottom: "8px",
                textAlign: "center",
              }}
            >
              MÜŞTERİ BORCU HATIRLATMA
            </h3>
            <div style={{ fontSize: "14px", marginBottom: "12px" }}>
              <b>{odemeSozuPopup.musteriAd}</b> isimli müşterinin{" "}
              <b>{odemeSozuPopup.odemeSozu}</b> tarihli ödeme sözü vardır.
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: "8px",
              }}
            >
              <button
                onClick={odemeSozuPopupKapat}
                style={{
                  padding: "6px 10px",
                  borderRadius: "6px",
                  border: "1px solid #bfa37d",
                  background: "#fdf4e4",
                  cursor: "pointer",
                }}
              >
                TAMAM
              </button>
              <button
                onClick={odemeSozuPopupDetayaGit}
                style={{
                  padding: "6px 10px",
                  borderRadius: "6px",
                  border: "none",
                  background: "#4b2e05",
                  color: "#fff",
                  cursor: "pointer",
                }}
              >
                BORÇ DETAYINA GİT
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
